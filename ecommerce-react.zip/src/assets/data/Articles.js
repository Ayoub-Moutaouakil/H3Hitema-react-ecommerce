let articles = [
    {
        id: 1,
        nom: "Article 1",
        description: "Description 1",
        prix: 10,
    },
    {
        id: 2,
        nom: "Article 2",
        description: "Description 2",
        prix: 20,
    },
    {
        id: 3,
        nom: "Article 3",
        description: "Description 3",
        prix: 30,
    },
    {
        id: 3,
        nom: "Article 3",
        description: "Description 3",
        prix: 30,
    },
    {
        id: 3,
        nom: "Article 3",
        description: "Description 3",
        prix: 30,
    },
    {
        id: 3,
        nom: "Article 3",
        description: "Description 3",
        prix: 30,
    },
    {
        id: 3,
        nom: "Article 3",
        description: "Description 3",
        prix: 30,
    },
    {
        id: 3,
        nom: "Article 3",
        description: "Description 3",
        prix: 30,
    },
];

export function getArticles() {
    return articles
}