import { Link, Outlet } from "react-router-dom";
import { HeaderContainer, HeaderWrapper } from "../components/Header/HeaderElements";

function Accueil(props) {

    const articles = props.articles;

    function ajouterAuPanier(e, article) {
        e.preventDefault();
        props.setPanier((prevData) => {
            prevData.Articles.push(article);
            return { ...prevData , Articles: prevData.Articles}
        })
    }

    return (
        <div>
            <h1>E-Commerce with React by Ayoub Moutaouakil!</h1>
            <nav
            style={{
                borderBottom: "solid 1px",
                paddingBottom: "1rem",
            }}
            >
            <Link to="/">Accueil</Link> |{" "}
            <Link to="/panier">Panier</Link> |{" "}
            <Link to="/historique">Historique</Link>
            </nav>
            <div class="container">
                <div class="row">
                    {articles.Articles.map( (article) => (
                        <div class="col-md-2">
                            <h3>{article.id}</h3>
                            <h3>{article.nom}</h3>
                            <p>{article.description}</p>
                            <h3>{article.prix}€</h3>
                            <button
                                href="#"
                                onClick={(e) => ajouterAuPanier(e, article)}
                                className="btn btn-primary"
                                >
                                Ajouter au panier
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default Accueil;