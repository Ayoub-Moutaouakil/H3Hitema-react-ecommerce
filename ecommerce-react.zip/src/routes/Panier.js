import { Link, Outlet } from "react-router-dom";
import { useState } from 'react';

function Panier(props) {

    const panier = props.panier.Articles
    const [form, setForm] = useState({
        nom: "",
        email: "",
        adresse: "",
        commentaire: "",
    });

    function handleChange(e) {
        // récupérer la valeur saisie en fonction du champ
        console.log(e.target.name);
        console.log(e.target.value);
        const { name, value } = e.target;
        // exécuter un setForm => mise à jour du state => relancer un render
        setForm({ ...form, [name]: value });
    }

    function handleSubmit(e) {
        e.preventDefault(); //  bloquer le rechargement de page
        const { nom, email, adresse, commentaire } = form;
        if (
            nom.length > 0 &&
            email.length > 0 &&
            adresse.length > 0 &&
            commentaire.length > 0
        ) {
            //console.log(form);
            setForm({ nom: "", email: "", adresse: "", commentaire: "" }); // vider le formulaire
        } else {
            alert("veuillez compléter les champs ");
        }
    }

    return (
        <div>
            <h1>E-Commerce with React by Ayoub Moutaouakil!</h1>
            <nav
                style={{
                    borderBottom: "solid 1px",
                    paddingBottom: "1rem",
                }}
            >
                <Link to="/">Accueil</Link> |{" "}
                <Link to="/panier">Panier</Link> |{" "}
                <Link to="/historique">Historique</Link>
            </nav>
            <main style={{ padding: "1rem 0" }}>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Prix</th>
                        </tr>
                    </thead>
                    {panier.map((article) => (
                        <tbody>
                            <tr>
                                <td>{article.id}</td>
                                <td>{article.nom}</td>
                                <td>{article.description}</td>
                                <td>{article.prix}€</td>
                            </tr>
                        </tbody>
                    ))}
                </table>
                <div className="col-sm-17">
                    <h2>Votre profil</h2>
                    <form onSubmit={handleSubmit}>
                        <input
                            type="text"
                            className="form-control my-3"
                            name="nom"
                            value={form.nom}
                            placeholder="votre nom"
                            onChange={handleChange}
                        />
                        <input
                            type="text"
                            className="form-control my-3"
                            name="email"
                            value={form.email}
                            placeholder="votre email"
                            onChange={handleChange}
                        />
                        <input
                            type="text"
                            className="form-control my-3"
                            name="adresse"
                            value={form.adresse}
                            placeholder="votre rue/code postal/ville"
                            onChange={handleChange}
                        />
                        <textarea
                            id=""
                            cols="30"
                            rows="5"
                            className="form-control my-3"
                            name="commentaire"
                            onChange={handleChange}
                            value={form.commentaire}
                            placeholder="commentaire"
                        ></textarea>
                        <input type="submit" className="btn btn-warning" value="Commander" />
                    </form>
                </div>
            </main>
        </div>
    )
}

export default Panier;