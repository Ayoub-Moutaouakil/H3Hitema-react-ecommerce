import { Link, Outlet } from "react-router-dom";

function Historique() {
    return (
        <div>
        <h1>E-Commerce with React by Ayoub Moutaouakil!</h1>
        <nav
        style={{
            borderBottom: "solid 1px",
            paddingBottom: "1rem",
        }}
        >
        <Link to="/">Accueil</Link> |{" "}
        <Link to="/panier">Panier</Link> |{" "}
        <Link to="/historique">Historique</Link>
        </nav>
        <main style={{ padding: "1rem 0" }}>
            <h2>Historique</h2>
        </main>
    </div>
    );
}

export default Historique;