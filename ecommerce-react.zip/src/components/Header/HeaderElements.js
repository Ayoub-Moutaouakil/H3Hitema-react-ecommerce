import styled from 'styled-components';

export const HeaderContainer = styled.header`
    background: #61DAFB;
    display: flex;
    min-height: 10vh;
    width: 100%
`

export const HeaderWrapper = styled.section`
    width: 100%;
    display: flex;
    flex-direction: row;
`

export const HeaderLeft = styled.div`

`