function Article(props) {

    const {id, nom, description, prix} = props.article;

    return (
        <div class="col-md-2">
            <h3>{id}</h3>
            <h3>{nom}</h3>
            <p>{description}</p>
            <h3>{prix}€</h3>
        </div>
    )
}

export default Article;